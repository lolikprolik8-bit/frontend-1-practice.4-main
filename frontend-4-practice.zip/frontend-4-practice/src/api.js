async function request(url) {
  let response;

  try {
    response = await fetch(url);
  } catch {
    throw new Error('Не удалось связаться с сервером. Проверьте подключение и повторите попытку.');
  }

  let data;
  try {
    data = await response.json();
  } catch {
    data = null;
  }

  if (!response.ok) {
    throw new Error(data?.error || `Ошибка сервера (${response.status}).`);
  }

  if (!data) {
    throw new Error('Сервер вернул некорректный ответ.');
  }

  return data;
}

// Получить сегодняшнюю дату с сервера.
export function fetchToday() {
  return request('/api/booking/today');
}

// Получить слоты для выбранной даты.
// month передаётся в формате JavaScript: 0 — январь, 11 — декабрь.
export function fetchSlots(date) {
  const params = new URLSearchParams({
    day: String(date.day),
    month: String(date.month),
    year: String(date.year),
  });

  return request(`/api/slots?${params.toString()}`);
}
