import { useEffect, useMemo, useRef, useState } from 'react';
import { fetchSlots, fetchToday } from './api.js';

const WEEK_DAYS = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];
const MONTHS = [
  'Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь',
  'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь',
];

function sameDate(first, second) {
  return Boolean(first && second)
    && first.day === second.day
    && first.month === second.month
    && first.year === second.year;
}

function formatDate(date) {
  if (!date) return '';
  return new Date(date.year, date.month, date.day).toLocaleDateString('ru-RU', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });
}

export default function App() {
  const [today, setToday] = useState(null);
  const [todayLoading, setTodayLoading] = useState(true);
  const [todayError, setTodayError] = useState('');

  const [viewDate, setViewDate] = useState(null);
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedSlot, setSelectedSlot] = useState(null);

  const [slots, setSlots] = useState([]);
  const [slotsLoading, setSlotsLoading] = useState(false);
  const [slotsError, setSlotsError] = useState('');
  const [slotsReloadKey, setSlotsReloadKey] = useState(0);
  const requestIdRef = useRef(0);

  // Первый запрос: получаем сегодняшнюю дату с сервера.
  useEffect(() => {
    let cancelled = false;

    async function loadToday() {
      setTodayLoading(true);
      setTodayError('');

      try {
        const result = await fetchToday();
        if (cancelled) return;

        const valid = Number.isInteger(result.day)
          && Number.isInteger(result.month)
          && Number.isInteger(result.year)
          && result.day >= 1
          && result.month >= 0
          && result.month <= 11;

        if (!valid) throw new Error('Сервер вернул некорректную сегодняшнюю дату.');

        setToday(result);
        setSlotsLoading(true);
        setSelectedDate(result);
        setViewDate(new Date(result.year, result.month, 1));
      } catch (error) {
        if (!cancelled) setTodayError(error.message || 'Не удалось загрузить дату.');
      } finally {
        if (!cancelled) setTodayLoading(false);
      }
    }

    loadToday();
    return () => {
      cancelled = true;
    };
  }, []);

  // Второй запрос: загружаем слоты при первом выборе даты и при каждом её изменении.
  // cleanup + requestId защищают от ответов на старые запросы при быстрых кликах.
  useEffect(() => {
    if (!selectedDate) return undefined;

    let cancelled = false;
    const currentRequestId = ++requestIdRef.current;

    async function loadSlots() {
      setSlotsLoading(true);
      setSlotsError('');
      setSlots([]);
      setSelectedSlot(null);

      try {
        const result = await fetchSlots(selectedDate);
        const isCurrentRequest = currentRequestId === requestIdRef.current;
        const isCurrentDate = sameDate(result.date, selectedDate);

        if (cancelled || !isCurrentRequest || !isCurrentDate) return;
        setSlots(Array.isArray(result.slots) ? result.slots : []);
      } catch (error) {
        if (!cancelled && currentRequestId === requestIdRef.current) {
          setSlotsError(error.message || 'Не удалось загрузить свободное время.');
        }
      } finally {
        if (!cancelled && currentRequestId === requestIdRef.current) {
          setSlotsLoading(false);
        }
      }
    }

    loadSlots();
    return () => {
      cancelled = true;
    };
  }, [selectedDate, slotsReloadKey]);

  const calendarCells = useMemo(() => {
    if (!viewDate) return [];

    const year = viewDate.getFullYear();
    const month = viewDate.getMonth();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const mondayFirstOffset = (new Date(year, month, 1).getDay() + 6) % 7;

    return [
      ...Array(mondayFirstOffset).fill(null),
      ...Array.from({ length: daysInMonth }, (_, index) => index + 1),
    ];
  }, [viewDate]);

  function changeMonth(offset) {
    setViewDate((current) => new Date(
      current.getFullYear(),
      current.getMonth() + offset,
      1,
    ));
  }

  function chooseDay(day) {
    if (!day || !viewDate) return;
    const date = {
      day,
      month: viewDate.getMonth(),
      year: viewDate.getFullYear(),
    };
    if (sameDate(date, selectedDate)) return;
    setSlotsLoading(true);
    setSlotsError('');
    setSlots([]);
    setSelectedSlot(null);
    setSelectedDate(date);
  }

  function retryToday() {
    setToday(null);
    setSelectedDate(null);
    setViewDate(null);
    setTodayLoading(true);
    setTodayError('');
    fetchToday()
      .then((result) => {
        setToday(result);
        setSlotsLoading(true);
        setSelectedDate(result);
        setViewDate(new Date(result.year, result.month, 1));
      })
      .catch((error) => setTodayError(error.message || 'Не удалось загрузить дату.'))
      .finally(() => setTodayLoading(false));
  }

  if (todayLoading) {
    return (
      <main className="page page-centered">
        <div className="loading-card" role="status">
          <span className="spinner" aria-hidden="true" />
          <p>Загрузка…</p>
        </div>
      </main>
    );
  }

  if (todayError || !today || !viewDate) {
    return (
      <main className="page page-centered">
        <section className="message-card error-card" role="alert">
          <div className="message-icon">!</div>
          <h1>Не удалось открыть календарь</h1>
          <p>{todayError || 'Данные о сегодняшней дате недоступны.'}</p>
          <button className="primary-button" onClick={retryToday}>Повторить загрузку</button>
        </section>
      </main>
    );
  }

  return (
    <main className="page">
      <header className="page-header">
        <div className="eyebrow">ОНЛАЙН-ЗАПИСЬ</div>
        <h1>Выбор даты и времени</h1>
        <p>Выберите удобный день и свободное время для записи.</p>
      </header>

      <div className="booking-layout">
        <section className="panel calendar-panel" aria-label="Календарь">
          <div className="panel-heading">
            <div>
              <span className="section-kicker">ШАГ 1</span>
              <h2>Выберите дату</h2>
            </div>
            <span className="today-label">Сегодня: {formatDate(today)}</span>
          </div>

          <div className="calendar-toolbar">
            <button className="month-arrow" onClick={() => changeMonth(-1)} aria-label="Предыдущий месяц">‹</button>
            <h3>{MONTHS[viewDate.getMonth()]} {viewDate.getFullYear()}</h3>
            <button className="month-arrow" onClick={() => changeMonth(1)} aria-label="Следующий месяц">›</button>
          </div>

          <div className="calendar-grid calendar-weekdays">
            {WEEK_DAYS.map((day) => <span key={day}>{day}</span>)}
          </div>

          <div className="calendar-grid calendar-days">
            {calendarCells.map((day, index) => {
              if (!day) return <span className="empty-day" key={`empty-${index}`} />;

              const cellDate = { day, month: viewDate.getMonth(), year: viewDate.getFullYear() };
              const isToday = sameDate(cellDate, today);
              const isSelected = sameDate(cellDate, selectedDate);

              return (
                <button
                  key={day}
                  className={`day-button${isToday ? ' is-today' : ''}${isSelected ? ' is-selected' : ''}`}
                  onClick={() => chooseDay(day)}
                  aria-pressed={isSelected}
                  aria-label={`${day} ${MONTHS[viewDate.getMonth()]}`}
                >
                  {day}
                </button>
              );
            })}
          </div>

          <div className="calendar-legend">
            <span><i className="legend-dot selected-dot" /> Выбранная дата</span>
            <span><i className="legend-dot today-dot" /> Сегодня</span>
          </div>
        </section>

        <section className="panel slots-panel" aria-label="Доступное время">
          <div className="panel-heading">
            <div>
              <span className="section-kicker">ШАГ 2</span>
              <h2>Выберите время</h2>
            </div>
            {selectedDate && <span className="date-chip">{formatDate(selectedDate)}</span>}
          </div>

          {slotsLoading ? (
            <div className="slots-placeholder" role="status">
              <span className="spinner" aria-hidden="true" />
              <p>Загрузка слотов…</p>
            </div>
          ) : slotsError ? (
            <div className="inline-error" role="alert">
              <p>{slotsError}</p>
              <button className="secondary-button" onClick={() => setSlotsReloadKey((value) => value + 1)}>
                Повторить
              </button>
            </div>
          ) : slots.length === 0 ? (
            <div className="empty-slots">
              <div className="empty-calendar-icon">▦</div>
              <h3>Нет доступного времени</h3>
              <p>На выбранную дату свободные слоты не найдены. Попробуйте другой день.</p>
            </div>
          ) : (
            <>
              <p className="slots-description">Доступные интервалы:</p>
              <div className="slots-grid">
                {slots.map((slot) => (
                  <button
                    key={slot.time}
                    className={`slot-button${selectedSlot === slot.time ? ' slot-selected' : ''}`}
                    disabled={!slot.available}
                    onClick={() => setSelectedSlot(slot.time)}
                    aria-pressed={selectedSlot === slot.time}
                  >
                    {slot.time}
                    {!slot.available && <span className="slot-unavailable">Занято</span>}
                  </button>
                ))}
              </div>
              <div className="slot-legend">
                <span><i className="legend-dot available-dot" /> Свободно</span>
                <span><i className="legend-dot unavailable-dot" /> Занято</span>
              </div>
              {selectedSlot && (
                <div className="selection-summary" role="status">
                  Вы выбрали: <strong>{formatDate(selectedDate)}, {selectedSlot}</strong>
                </div>
              )}
            </>
          )}
        </section>
      </div>

      <footer className="page-footer">Данные календаря и свободного времени загружаются с имитационного сервера.</footer>
    </main>
  );
}
