import { today, slotsByDate } from './database.js';

// Задержка имитирует работу настоящего сервера и сети.
export const DELAY_MS = 900;

function sendJson(res, statusCode, data) {
  res.statusCode = statusCode;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.end(JSON.stringify(data));
}

export function mockApiPlugin() {
  return {
    name: 'mock-api-server',
    configureServer(server) {
      server.middlewares.use('/api', (req, res, next) => {
        if (req.method !== 'GET') {
          sendJson(res, 405, { error: 'Поддерживается только GET-запрос.' });
          return;
        }

        const url = new URL(req.url ?? '/', 'http://localhost');
        const pathname = url.pathname;

        if (pathname !== '/booking/today' && pathname !== '/slots') {
          next();
          return;
        }

        setTimeout(() => {
          // Этот параметр позволяет вручную проверить отображение ошибки:
          // /api/slots?day=20&month=10&year=2026&fail=1
          if (url.searchParams.get('fail') === '1') {
            sendJson(res, 500, { error: 'Тестовая ошибка имитационного сервера.' });
            return;
          }

          if (pathname === '/booking/today') {
            sendJson(res, 200, today);
            return;
          }

          const day = Number(url.searchParams.get('day'));
          const month = Number(url.searchParams.get('month'));
          const year = Number(url.searchParams.get('year'));

          const validDate = Number.isInteger(day)
            && Number.isInteger(month)
            && Number.isInteger(year)
            && day >= 1
            && day <= 31
            && month >= 0
            && month <= 11
            && year >= 1970
            && !Number.isNaN(new Date(year, month, day).getTime())
            && new Date(year, month, day).getDate() === day
            && new Date(year, month, day).getMonth() === month;

          if (!validDate) {
            sendJson(res, 400, { error: 'Передана некорректная дата.' });
            return;
          }

          const dateKey = `${year}-${month}-${day}`;
          sendJson(res, 200, {
            date: { day, month, year },
            slots: slotsByDate[dateKey] ?? [],
          });
        }, DELAY_MS);
      });
    },
  };
}
