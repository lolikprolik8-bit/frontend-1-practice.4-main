// Имитация базы данных. Месяц в объекте today и ключах слотов — 0-индексный.
// Например, 9 означает октябрь.
export const today = {
  day: 17,
  month: 9,
  year: 2026,
};

// Два набора слотов для двух дат.
// Формат каждого слота: { time, available }.
export const slotsByDate = {
  '2026-9-17': [
    { time: '09:00', available: true },
    { time: '10:00', available: false },
    { time: '11:00', available: true },
    { time: '12:00', available: true },
    { time: '14:00', available: false },
    { time: '15:00', available: true },
  ],
  '2026-9-18': [
    { time: '09:30', available: true },
    { time: '10:30', available: true },
    { time: '11:30', available: false },
    { time: '13:00', available: true },
    { time: '14:30', available: true },
    { time: '16:00', available: false },
  ],
};
